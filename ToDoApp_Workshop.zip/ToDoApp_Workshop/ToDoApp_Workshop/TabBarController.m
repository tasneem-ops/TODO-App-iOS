//
//  TabBarController.m
//  ToDoApp_Workshop
//
//  Created by JETSMobileLabMini9 on 17/04/2024.
//

#import "TabBarController.h"
#import "AddViewController.h"

@interface TabBarController ()
@property UIBarButtonItem *buttonAdd;
@end

@implementation TabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    _buttonAdd = [[UIBarButtonItem alloc] initWithTitle:nil image:[UIImage systemImageNamed:@"plus"] target:self action:@selector(addTask) menu:nil];
    
    self.navigationItem.rightBarButtonItem = _buttonAdd;
}

-(void) addTask{
    AddViewController *addScreen = [self.storyboard instantiateViewControllerWithIdentifier:@"add_task"];
    addScreen.isAddingNewTask = YES;
    addScreen.editEnabled = YES;
   [self.navigationController pushViewController:addScreen animated:YES];
}
@end
