//
//  SceneDelegate.h
//  ToDoApp_Workshop
//
//  Created by JETSMobileLabMini9 on 17/04/2024.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

