//
//  AddViewController.h
//  ToDoApp_Workshop
//
//  Created by JETSMobileLabMini9 on 17/04/2024.
//

#import <UIKit/UIKit.h>
#import "Task.h"

NS_ASSUME_NONNULL_BEGIN

@interface AddViewController : UIViewController

@property BOOL isAddingNewTask;
@property BOOL editEnabled;
@property Task *savedTask;
@end

NS_ASSUME_NONNULL_END
