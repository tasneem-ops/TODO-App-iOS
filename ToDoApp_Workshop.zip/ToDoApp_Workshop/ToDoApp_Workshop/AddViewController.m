//
//  AddViewController.m
//  ToDoApp_Workshop
//
//  Created by JETSMobileLabMini9 on 17/04/2024.
//

#import "AddViewController.h"
#import "Task.h"
#import <UserNotifications/UNUserNotificationCenter.h>
#import <UserNotifications/UNNotificationContent.h>
#import <UserNotifications/UNNotificationRequest.h>
#import <UserNotifications/UNNotificationTrigger.h>
#import <UserNotifications/UNNotificationSound.h>

@interface AddViewController ()
@property (weak, nonatomic) IBOutlet UITextField *titleText;
@property (weak, nonatomic) IBOutlet UITextView *descriptionText;

@property (weak, nonatomic) IBOutlet UISegmentedControl *priority;
@property (weak, nonatomic) IBOutlet UISegmentedControl *state;
@property (weak, nonatomic) IBOutlet UIDatePicker *datePicker;
@property (weak, nonatomic) IBOutlet UIButton *ConfirmButton;
@property (weak, nonatomic) IBOutlet UIImageView *priorityImage;
@property BOOL isNotificationRequestGranted;


@end

@implementation AddViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSDate *todayDate = [[NSDate alloc] initWithTimeIntervalSinceNow:0.0];
    [_datePicker setMinimumDate:todayDate];
    [_priority addAction:<#(nonnull UIAction *)#> forControlEvents:<#(UIControlEvents)#>];
}
-(void) viewWillAppear:(BOOL)animated{

    [_state setEnabled:NO forSegmentAtIndex:0];
    [_state setEnabled:NO forSegmentAtIndex:1];
    [_state setEnabled:NO forSegmentAtIndex:2];
    [_priority setEnabled:NO forSegmentAtIndex:0];
    [_priority setEnabled:NO forSegmentAtIndex:1];
    [_priority setEnabled:NO forSegmentAtIndex:2];
    if(! _isAddingNewTask){
        _priorityImage.hidden = NO;
        _titleText.text = _savedTask.taskTitle;
        _descriptionText.text = _savedTask.taskDesc;
        _datePicker.date = _savedTask.taskDate;
        [_priority setSelectedSegmentIndex:_savedTask.priority];
        [_priority setEnabled:YES forSegmentAtIndex:_savedTask.priority];
        [_state setSelectedSegmentIndex:_savedTask.status];
        [_state setEnabled:YES forSegmentAtIndex:_savedTask.status];
        switch (_savedTask.priority) {
            case 0:
                _priorityImage.image = [UIImage imageNamed:@"low.png"];
                break;
            case 1:
                _priorityImage.image = [UIImage imageNamed:@"medium.png"];
                break;
            case 2:
                _priorityImage.image = [UIImage imageNamed:@"high.png"];
                break;
                
            default:
                break;
        }
        if(_editEnabled){
            _ConfirmButton.hidden = NO;
            _ConfirmButton.hidden = NO;
            [_state setEnabled:YES forSegmentAtIndex:0];
            [_state setEnabled:YES forSegmentAtIndex:1];
            [_state setEnabled:YES forSegmentAtIndex:2];
            for(int i = 0; i<_savedTask.status; i++){
                [_state setEnabled:NO forSegmentAtIndex:i];
            }
            [_priority setEnabled:YES forSegmentAtIndex:0];
            [_priority setEnabled:YES forSegmentAtIndex:1];
            [_priority setEnabled:YES forSegmentAtIndex:2];
        }
        else{
            _ConfirmButton.hidden = YES;
        }
    }
    else{
        [_state setEnabled:YES forSegmentAtIndex:0];
        _priorityImage.hidden = YES;
        _ConfirmButton.hidden = NO;
        [_priority setEnabled:YES forSegmentAtIndex:0];
        [_priority setEnabled:YES forSegmentAtIndex:1];
        [_priority setEnabled:YES forSegmentAtIndex:2];
        [_priority setSelectedSegmentIndex:0];
        [_state setSelectedSegmentIndex:0];
    }
}

-(void) saveData{
    NSMutableArray *savedArray = [self getSavedData];
    
    Task *newTask = [self getInputData];
    [savedArray addObject:newTask];

    [self saveToDataSource:savedArray];
    [self enableNotification];
    [self.navigationController popViewControllerAnimated:YES];
}

-(void) editData{
    NSMutableArray *savedArray = [self getSavedData];
    for(int i=0; i<savedArray.count ; i++){
        Task *obj = [savedArray objectAtIndex:i];
        if([obj.taskTitle isEqual: _savedTask.taskTitle]){
            printf("Found That Object\n");
            [savedArray removeObjectAtIndex:i];
            Task *newTask = [self getInputData];
            [savedArray insertObject:newTask atIndex:i];
            break;
        }
    }
    [self saveToDataSource:savedArray];
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)saveOrEdit:(id)sender {
    if([self validateInputData]){
        if(_isAddingNewTask){
            [self showAlertConfirmSave];
        }
        else{
            [self showAlertConfirmEdit];
        }
    }
    else{
        [self showAlertDataNotValid];
    }
}
-(NSMutableArray *) getSavedData{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSData *savedData = [defaults objectForKey:@"tasks"];
    NSMutableArray *savedArray = [NSKeyedUnarchiver unarchiveObjectWithData:savedData];
    if([savedArray isEqual:nil] || savedArray.count == 0){
        return [NSMutableArray new];
    }
    return savedArray;
}
-(void ) saveToDataSource:(NSMutableArray *) savedArray{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:savedArray requiringSecureCoding:YES error:nil];
    [defaults setObject:data forKey:@"tasks"];
}
-(Task *) getInputData{
    Task *newTask = [Task new];
    newTask.taskTitle =  _titleText.text;
    newTask.taskDesc = _descriptionText.text;
    newTask.priority = (int) _priority.selectedSegmentIndex;
    newTask.status = (int) _state.selectedSegmentIndex;
    newTask.taskDate = _datePicker.date;
    return  newTask;
}
-(BOOL) validateInputData{
    Task *task = [self getInputData];
    if([task.taskTitle isEqual: @""] || [task.taskDesc isEqual:@""] ){
        return NO;
    }
    else{
        return YES;
    }
}
-(void) showAlertDataNotValid{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Invalid Data" message:@"Please Fill Data Correctly" preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action){
        
    }];
    
    [alert addAction:action];
    [self presentViewController:alert animated:YES completion:nil];
}
-(void) showAlertConfirmSave{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Add Task" message:@"This task will be added to To Do List" preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"Save" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action){
        [self saveData];
    }];
    UIAlertAction *action2 = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action){
        
    }];
    [alert addAction:action];
    [alert addAction:action2];
    [self presentViewController:alert animated:YES completion:nil];
}
-(void) showAlertConfirmEdit{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Edit Task" message:@"This task will be edited." preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"Edit" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action){
        [self editData];
    }];
    UIAlertAction *action2 = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action){
        
    }];
    [alert addAction:action];
    [alert addAction:action2];
    [self presentViewController:alert animated:YES completion:nil];
}
-(void) enableNotification{
    UNUserNotificationCenter *center = [UNUserNotificationCenter currentNotificationCenter];
    UNAuthorizationOptions options = UNAuthorizationOptionAlert + UNAuthorizationOptionSound;
    [center requestAuthorizationWithOptions:options completionHandler:^(BOOL granted, NSError *error){
        self->_isNotificationRequestGranted = granted;
    }];
    UNMutableNotificationContent *content = [[UNMutableNotificationContent alloc] init];
    content.title = @"Task Deadline!";
    content.body = [[NSString alloc] initWithFormat:@"Deadline for Task:  %@", _titleText.text];
    content.sound = [UNNotificationSound defaultSound];
    NSTimeInterval interval = [_datePicker.date timeIntervalSinceDate:NSDate.now];
    if(interval < 0){
        interval =1;
    }
    UNTimeIntervalNotificationTrigger *trigger = [UNTimeIntervalNotificationTrigger
                                                  triggerWithTimeInterval:interval repeats:NO];
    UNNotificationRequest *request = [UNNotificationRequest requestWithIdentifier:@"TaskNotification" content:content trigger:trigger];
    [center addNotificationRequest:request withCompletionHandler:nil];
    printf("Showing Notification\n");
}

-(void) priorityChanged{
    int p = (int) _priority.selectedSegmentIndex;
    [_priorityImage setHidden:NO];
    switch (p) {
        case 0:
            _priorityImage.image = [UIImage imageNamed:@"low.png"];
            break;
        case 1:
            _priorityImage.image = [UIImage imageNamed:@"medium.png"];
            break;
        case 2:
            _priorityImage.image = [UIImage imageNamed:@"high.png"];
            break;
            
        default:
            break;
    }
}
@end
