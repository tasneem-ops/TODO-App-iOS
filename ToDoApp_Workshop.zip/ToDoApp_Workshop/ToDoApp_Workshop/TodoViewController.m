//
//  TodoViewController.m
//  ToDoApp_Workshop
//
//  Created by JETSMobileLabMini9 on 17/04/2024.
//

#import "TodoViewController.h"
#import "AddViewController.h"
#import "Task.h"

@interface TodoViewController ()
@property (weak, nonatomic) IBOutlet UITableView *table;
@property NSMutableArray *array;
@property NSMutableArray *allToDoTasks;
@property NSMutableArray *lowPriorityTasks;
@property NSMutableArray *mediumPriorityTasks;
@property NSMutableArray *highPriorityTasks;
@property (weak, nonatomic) IBOutlet UIImageView *noDataImage;
@property Task *selectedTask;
@property (weak, nonatomic) IBOutlet UITextField *searchField;
@property (weak, nonatomic) IBOutlet UIImageView *filterButton;
@property BOOL isFiltered;

@end

@implementation TodoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _table.delegate = self;
    _table.dataSource = self;
    _searchField.leftViewMode = UITextFieldViewModeAlways;
    UIImage *searchIcon = [UIImage systemImageNamed:@"magnifyingglass"];
    _searchField.leftView = [[UIImageView alloc] initWithImage:searchIcon];
    _isFiltered = NO;
    UIGestureRecognizer *tapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(changeFilterState)];
    [_filterButton addGestureRecognizer:tapRecognizer];
    [_filterButton setUserInteractionEnabled:YES];
    [_searchField addTarget:self action:@selector(searchTasks) forControlEvents:UIControlEventEditingChanged];
}
- (void)viewWillAppear:(BOOL)animated{
    [self.navigationController setNavigationBarHidden:NO animated:YES];
    [self.tabBarController.navigationItem.rightBarButtonItem setHidden:NO];
    self.tabBarController.navigationController.navigationBar.topItem.title = @"To-Do Tasks";
    [self loadData];
}


- (nonnull UITableViewCell *)tableView:(nonnull UITableView *)tableView cellForRowAtIndexPath:(nonnull NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if(cell == nil){
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    UIButton *deleteButton = [cell viewWithTag:3];
    UIButton *editButton = [cell viewWithTag:4];
    UILabel *label = [cell viewWithTag:2];
    UIImageView *imageView = [cell viewWithTag:1];
    editButton.hidden = YES;
    deleteButton.hidden = YES;
    
    if(_isFiltered){
        if(indexPath.section == 0){
            Task *x = [_highPriorityTasks objectAtIndex:indexPath.row];
            label.text = x.taskTitle;
            imageView.image = [UIImage imageNamed:@"high.png"];
        }
        else if(indexPath.section == 1){
            Task *x = [_mediumPriorityTasks objectAtIndex:indexPath.row];
            label.text = x.taskTitle;
            imageView.image = [UIImage imageNamed:@"medium.png"];
        }
        else if(indexPath.section == 2){
            Task *x = [_lowPriorityTasks objectAtIndex:indexPath.row];
            label.text = x.taskTitle;
            imageView.image = [UIImage imageNamed:@"low.png"];
        }
    }
    else{
        Task *currentTask = [_array objectAtIndex:indexPath.row];
        NSLog(@"%@", currentTask.taskTitle);
        label.text = currentTask.taskTitle;
        switch (currentTask.priority) {
            case 0:
                imageView.image = [UIImage imageNamed:@"low.png"];
                break;
            case 1:
                imageView.image = [UIImage imageNamed:@"medium.png"];
                break;
            case 2:
                imageView.image = [UIImage imageNamed:@"high.png"];
                break;
            default:
                break;
        }
    }
    
    return cell;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    if(_isFiltered){
        switch (section) {
            case 0:
                return @"High Priority";
                break;
            case 1:
                return @"Medium Priority";
                break;
            case 2:
                return @"Low Priority";
                break;
            default:
                break;
        }
    }
    return @"All Tasks";
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    AddViewController *addScreen = [self.storyboard instantiateViewControllerWithIdentifier:@"add_task"];
    addScreen.isAddingNewTask = NO;
    addScreen.editEnabled = YES;
    if(_isFiltered){
        switch (indexPath.section) {
            case 0:
                _selectedTask = [_highPriorityTasks objectAtIndex:indexPath.row];
                break;
            case 1:
                _selectedTask = [_mediumPriorityTasks objectAtIndex:indexPath.row];
                break;
            case 2:
                _selectedTask = [_lowPriorityTasks objectAtIndex:indexPath.row];
                break;
            default:
                break;
        }
    }
    else{
        _selectedTask = [_array objectAtIndex:indexPath.row];
    }
    addScreen.savedTask = _selectedTask;
    [self presentViewController:addScreen animated:YES completion:^(void){}];
}
- (UISwipeActionsConfiguration *)tableView:(UITableView *)tableView trailingSwipeActionsConfigurationForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSLog(@"Trailing");
    [_table reloadData];
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    UIButton *deleteButton = [cell viewWithTag:3];
    UIButton *editButton = [cell viewWithTag:4];
    UILabel *label = [cell viewWithTag:2];
    UIImageView *imageView = [cell viewWithTag:1];
    editButton.hidden = NO;
    deleteButton.hidden = NO;
    if(_isFiltered){
        switch (indexPath.section) {
            case 0:
                _selectedTask = [_highPriorityTasks objectAtIndex:indexPath.row];
                break;
            case 1:
                _selectedTask = [_mediumPriorityTasks objectAtIndex:indexPath.row];
                break;
            case 2:
                _selectedTask = [_lowPriorityTasks objectAtIndex:indexPath.row];
                break;
            default:
                break;
        }
    }
    else{
        _selectedTask = [_array objectAtIndex:indexPath.row];
    }
    [deleteButton addTarget:self action:@selector(showAlertDelete)  forControlEvents:UIControlEventTouchDown];
    [editButton addTarget:self action:@selector(editTask)  forControlEvents:UIControlEventTouchDown];
    return [UISwipeActionsConfiguration new];
}
- (UISwipeActionsConfiguration *)tableView:(UITableView *)tableView leadingSwipeActionsConfigurationForRowAtIndexPath:(NSIndexPath *)indexPath{
    [_table reloadData];
    return [UISwipeActionsConfiguration new];
}
- (NSInteger)tableView:(nonnull UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if(_isFiltered){
        switch (section) {
            case 0:
                return _highPriorityTasks.count;
                break;
            case 1:
                return _mediumPriorityTasks.count;
                break;
            case 2:
                return _lowPriorityTasks.count;;
                break;
            default:
                break;
        }
    }
    return  _array.count;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if(_isFiltered){
        return 3;
    }
    return 1;
}
-(void) loadData{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSData *savedData = [defaults objectForKey:@"tasks"];
    NSSet *set = [NSSet setWithArray:@[
        [NSMutableArray class],
        [Task class]
    ]];
    NSMutableArray<Task *> *savedArray = (NSMutableArray *)[NSKeyedUnarchiver unarchivedObjectOfClasses:set fromData:savedData error:nil];
    printf("Array Count Saved%lu\n" , (unsigned long)savedArray.count);
    _array = [NSMutableArray new];
    for(int i =0; i<savedArray.count; i++){
        Task *thisTask = [savedArray objectAtIndex:i];
        if(thisTask.status == 0){
            [_array addObject:thisTask];
        }
    }
    printf("Array Count %lu\n" , (unsigned long)_array.count);
    _allToDoTasks = [[NSMutableArray alloc] initWithArray:_array];
    printf("Array Count All %lu\n" , (unsigned long)_allToDoTasks.count);
    printf("%d", (int)savedArray.count);
    if(_array.count == 0){
        _table.hidden = YES;
        _noDataImage.hidden = NO;
    }
    else{
        _table.hidden = NO;
        _noDataImage.hidden = YES;
    }
    [self filterData];
    [_table reloadData];
}
-(void) deleteTask{
    NSLog(@"Started Delete Function");
    NSMutableArray *savedArray = [self getSavedData];
    for(int i=0; i<savedArray.count ; i++){
        Task *obj = [savedArray objectAtIndex:i];
        if([obj.taskTitle isEqual: _selectedTask.taskTitle]){
            printf("Found That Object\n");
            [savedArray removeObjectAtIndex:i];
            break;
        }
    }
    NSLog(@"ended Searching fro delete");
    [self saveToDataSource:savedArray];
    [self loadData];
}
-(void) editTask{
    NSLog(@"Edit");
    AddViewController *addScreen = [self.storyboard instantiateViewControllerWithIdentifier:@"add_task"];
    addScreen.isAddingNewTask = NO;
    addScreen.editEnabled = YES;
    addScreen.savedTask = _selectedTask;
   [self.navigationController pushViewController:addScreen animated:YES];
}
-(NSMutableArray *) getSavedData{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSData *savedData = [defaults objectForKey:@"tasks"];
    NSMutableArray *savedArray = [NSKeyedUnarchiver unarchiveObjectWithData:savedData];
    return savedArray;
}
-(void ) saveToDataSource:(NSMutableArray *) savedArray{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:savedArray requiringSecureCoding:YES error:nil];
    [defaults setObject:data forKey:@"tasks"];
}

-(void) showAlertDelete{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Delete Task" message:@"Are you sure you want to delete this app?" preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"Delete" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action){
        [self deleteTask];
    }];
    UIAlertAction *action2 = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action){
        
    }];
    [alert addAction:action];
    [alert addAction:action2];
    [self presentViewController:alert animated:YES completion:nil];
}
-(void) changeFilterState{
    if(_isFiltered){
        _isFiltered = NO;
    }
    else{
        _isFiltered = YES;
    }
    [_table reloadData];
}
-(void) filterData{
    _lowPriorityTasks = [NSMutableArray new];
    _mediumPriorityTasks = [NSMutableArray new];
    _highPriorityTasks = [NSMutableArray new];
    for(int i =0; i<_array.count; i++){
        Task *task = [_array objectAtIndex:i];
        switch (task.priority) {
            case 0:
                [_lowPriorityTasks addObject:task];
                break;
            case 1:
                [_mediumPriorityTasks addObject:task];
                break;
            case 2:
                [_highPriorityTasks addObject:task];
                break;
            default:
                break;
        }
    }
    for(int i =0; i<_lowPriorityTasks.count; i++){
        Task *task = [_lowPriorityTasks objectAtIndex:i];
        NSLog(@"Filter Low  %@", task.taskTitle);
    }
    for(int i =0; i<_mediumPriorityTasks.count; i++){
        Task *task = [_mediumPriorityTasks objectAtIndex:i];
        NSLog(@"Filter _mediumPriorityTasks  %@", task.taskTitle);
    }
    for(int i =0; i<_highPriorityTasks.count; i++){
        Task *task = [_highPriorityTasks objectAtIndex:i];
        NSLog(@"Filter _highPriorityTasks   %@", task.taskTitle);
    }
}

-(void) searchTasks{
    NSString *text = _searchField.text;
    [_array removeAllObjects];
    if([text isEqualToString:@""]){
        for(int i = 0; i<_allToDoTasks.count; i++){
            Task *task = [_allToDoTasks objectAtIndex:i];
            [_array addObject:task];
        }
    }
    else{
        for(int i = 0; i<_allToDoTasks.count; i++){
            Task *task = [_allToDoTasks objectAtIndex:i];
            if([task.taskTitle rangeOfString:text options:NSCaseInsensitiveSearch].location != NSNotFound){
                [_array addObject:task];
            }
        }
    }
    [self filterData];
    [_table reloadData];
}
@end
