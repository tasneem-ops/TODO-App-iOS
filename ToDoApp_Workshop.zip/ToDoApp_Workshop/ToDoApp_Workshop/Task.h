//
//  Task.h
//  ToDoApp_Workshop
//
//  Created by JETSMobileLabMini9 on 17/04/2024.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Task : NSObject <NSCoding, NSSecureCoding>

@property NSString *taskTitle;
@property NSString *taskDesc;
@property int priority;
@property int status;
@property NSDate *taskDate;

-(void) encodeWithCoder:(NSCoder *)coder;

@end

NS_ASSUME_NONNULL_END
