//
//  Task.m
//  ToDoApp_Workshop
//
//  Created by JETSMobileLabMini9 on 17/04/2024.
//

#import "Task.h"

@implementation Task

- (void)encodeWithCoder:(nonnull NSCoder *)coder {
    [coder encodeObject:_taskTitle forKey:@"taskTitle"];
    [coder encodeObject:_taskDesc forKey:@"taskDesc"];
    [coder encodeInt:_priority forKey:@"priority"];
    [coder encodeInt:_status forKey:@"status"];
    [coder encodeObject:_taskDate forKey:@"taskDate"];
}

- (nullable instancetype)initWithCoder:(nonnull NSCoder *)coder {
    if(self == [super init]){
        _taskTitle = [coder decodeObjectOfClass:[NSString class] forKey:@"taskTitle"];
        _taskDesc = [coder decodeObjectOfClass:[NSString class] forKey:@"taskDesc"];
        _priority = [coder decodeIntForKey:@"priority"];
        _status = [coder decodeIntForKey:@"status"];
        _taskDate = [coder decodeObjectOfClass:[NSDate class] forKey:@"taskDate"];
    }
    return  self;
}

+(BOOL) supportsSecureCoding{
    return YES;
}

@end
